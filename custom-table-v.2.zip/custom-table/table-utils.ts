import type { FormatterTableColumn, FormatterTableRow, TableStatusTone } from './table';

export type SortDirection = 'asc' | 'desc';

const monthAbbreviations = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const getMatchingStatusOption = (value: unknown, column?: FormatterTableColumn) => {
  if (!column || column.type !== 'status') {
    return null;
  }

  if (value === null || value === undefined || value === '') {
    return null;
  }

  const normalizedValue = String(value).trim().toLowerCase();
  return column.statusOptions?.find((option) => option.value.trim().toLowerCase() === normalizedValue) ?? null;
};

export const getStatusDisplay = (
  value: unknown,
  column?: FormatterTableColumn,
): { value: string; tone: TableStatusTone } | null => {
  const matchingStatus = getMatchingStatusOption(value, column);

  if (!matchingStatus) {
    return null;
  }

  return {
    value: matchingStatus.value,
    tone: matchingStatus.tone ?? 'info',
  };
};

export const sortRows = (
  rows: FormatterTableRow[],
  columnKey: string,
  direction: SortDirection,
  dateColumnKeys: string[] = [],
  statusColumns: FormatterTableColumn[] = [],
): FormatterTableRow[] => {
  if (!columnKey) {
    return rows;
  }

  const sortedRows = [...rows];
  const shouldTreatAsDate = dateColumnKeys.includes(columnKey);
  const statusColumn = statusColumns.find((column) => column.key === columnKey);

  sortedRows.sort((leftRow, rightRow) => {
    const leftValue = leftRow[columnKey];
    const rightValue = rightRow[columnKey];

    return compareValues(leftValue, rightValue, direction, shouldTreatAsDate, statusColumn);
  });

  return sortedRows;
};

const compareValues = (
  leftValue: unknown,
  rightValue: unknown,
  direction: SortDirection,
  shouldTreatAsDate: boolean,
  statusColumn?: FormatterTableColumn,
): number => {
  const normalizedLeftValue = normalizeValue(leftValue, shouldTreatAsDate, statusColumn);
  const normalizedRightValue = normalizeValue(rightValue, shouldTreatAsDate, statusColumn);

  if (normalizedLeftValue === null && normalizedRightValue === null) {
    return 0;
  }

  if (normalizedLeftValue === null) {
    return 1;
  }

  if (normalizedRightValue === null) {
    return -1;
  }

  if (typeof normalizedLeftValue === 'number' && typeof normalizedRightValue === 'number') {
    return direction === 'asc'
      ? normalizedLeftValue - normalizedRightValue
      : normalizedRightValue - normalizedLeftValue;
  }

  if (normalizedLeftValue instanceof Date && normalizedRightValue instanceof Date) {
    const dateComparison = normalizedLeftValue.getTime() - normalizedRightValue.getTime();
    return direction === 'asc' ? dateComparison : -dateComparison;
  }

  if (typeof normalizedLeftValue === 'boolean' && typeof normalizedRightValue === 'boolean') {
    const booleanComparison = Number(normalizedLeftValue) - Number(normalizedRightValue);
    return direction === 'asc' ? booleanComparison : -booleanComparison;
  }

  const leftText = String(normalizedLeftValue).trim().toLowerCase();
  const rightText = String(normalizedRightValue).trim().toLowerCase();
  const textComparison = leftText.localeCompare(rightText, undefined, { sensitivity: 'base' });

  return direction === 'asc' ? textComparison : -textComparison;
};

const normalizeValue = (
  value: unknown,
  shouldTreatAsDate: boolean,
  statusColumn?: FormatterTableColumn,
): number | boolean | Date | string | null => {
  if (value === null || value === undefined || value === '') {
    return null;
  }

  if (typeof value === 'number' && Number.isFinite(value)) {
    return value;
  }

  if (typeof value === 'boolean') {
    return value;
  }

  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value;
  }

  if (typeof value === 'string') {
    if (shouldTreatAsDate) {
      const parsedDateValue = parseDateValue(value);
      if (parsedDateValue !== null) {
        return parsedDateValue;
      }
    }

    if (statusColumn?.type === 'status') {
      const statusOption = getMatchingStatusOption(value, statusColumn);
      return statusOption?.value ?? value;
    }

    const numericValue = parseNumberValue(value);
    if (numericValue !== null) {
      return numericValue;
    }

    return value;
  }

  return String(value);
};

const parseNumberValue = (value: string): number | null => {
  const trimmedValue = value.trim();
  if (!trimmedValue) {
    return null;
  }

  const sanitizedValue = trimmedValue.replace(/[^\d,.-]/g, '');
  if (!sanitizedValue) {
    return null;
  }

  const hasDot = sanitizedValue.includes('.');
  const hasComma = sanitizedValue.includes(',');

  let normalizedValue = sanitizedValue;

  if (hasDot && hasComma) {
    const lastDot = sanitizedValue.lastIndexOf('.');
    const lastComma = sanitizedValue.lastIndexOf(',');
    const decimalSeparator = lastDot > lastComma ? '.' : ',';
    const thousandSeparator = decimalSeparator === '.' ? ',' : '.';

    normalizedValue = sanitizedValue.split(thousandSeparator).join('');
    if (decimalSeparator === ',') {
      normalizedValue = normalizedValue.replace(',', '.');
    }
  } else if (hasComma) {
    normalizedValue = /,\d{1,2}$/.test(sanitizedValue)
      ? sanitizedValue.replace(',', '.')
      : sanitizedValue.split(',').join('');
  } else if (hasDot) {
    normalizedValue = /\.\d{1,2}$/.test(sanitizedValue) ? sanitizedValue : sanitizedValue.split('.').join('');
  }

  const parsedValue = Number(normalizedValue);
  return Number.isNaN(parsedValue) ? null : parsedValue;
};

const parseDateValue = (value: string): Date | null => {
  const trimmedValue = value.trim();
  if (!trimmedValue) {
    return null;
  }

  const directDate = new Date(trimmedValue);
  if (!Number.isNaN(directDate.getTime())) {
    return directDate;
  }

  const withoutTimezone = trimmedValue.replace(/\s[A-Z]{2,5}\s(\d{4})$/, ' $1');
  const sanitizedDate = new Date(withoutTimezone);
  if (!Number.isNaN(sanitizedDate.getTime())) {
    return sanitizedDate;
  }

  const rawDateMatch = trimmedValue.match(/^(?:[A-Za-z]{3}\s)?([A-Za-z]{3})\s(\d{1,2})\s\d{2}:\d{2}:\d{2}(?:\s[A-Z]{2,5})?\s(\d{4})$/);
  if (!rawDateMatch) {
    return null;
  }

  const monthIndex = monthAbbreviations.indexOf(rawDateMatch[1]);
  if (monthIndex === -1) {
    return null;
  }

  const day = Number(rawDateMatch[2]);
  const year = Number(rawDateMatch[3]);
  const manualDate = new Date(year, monthIndex, day);

  return Number.isNaN(manualDate.getTime()) ? null : manualDate;
};
