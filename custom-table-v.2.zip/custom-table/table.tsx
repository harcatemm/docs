import { Component, Event, EventEmitter, h, Prop, State } from '@stencil/core';
import { CustomTableIconName, renderCustomTableIcon } from './custom-table-icons';
import { SortDirection, getStatusDisplay, sortRows } from './table-utils';

export interface FormatterTableRow {
  [key: string]: string | number | boolean | null | undefined | unknown;
}

export type TableStatusTone = 'success' | 'danger' | 'warning' | 'info';

export interface TableStatusOption {
  value: string;
  tone?: TableStatusTone;
}

export interface FormatterTableColumn {
  key: string;
  label: string;
  sortable?: boolean;
  type?: 'default' | 'status';
  statusOptions?: TableStatusOption[];
}

export interface FormatterTableData {
  columns?: Array<string | FormatterTableColumn>;
  rows?: FormatterTableRow[];
}

export interface TableActionRequestDetail {
  selectedRow: FormatterTableRow;
  row: FormatterTableRow;
  reference: unknown;
  referenceKey: string;
  actionKey: string;
  actionLabel?: string;
}

export type TableActionMode = 'single' | 'group';

export interface TableActionButtonDefinition {
  key: string;
  label?: string;
  iconColor?: string;
  iconText?: string;
  iconName?: CustomTableIconName;
  disabled?: boolean;
}

export type TableDateFormat = 'default' | 'MMMdyyyy' | 'dd-mmm-yyyy';

export interface TableDateOptions {
  columnKeys: string[];
  format?: TableDateFormat;
}

@Component({
  tag: 'custom-table',
  styleUrl: 'table.css',
  shadow: true,
})
export class CustomTable {
  private readonly monthAbbreviations = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  private readonly monthLabels = ['Ene.', 'Feb.', 'Mar.', 'Abr.', 'May.', 'Jun.', 'Jul.', 'Ago.', 'Sep.', 'Oct.', 'Nov.', 'Dic.'];

  @Prop() tableTitle = '';
  @Prop() emptyText = 'Sin registros';
  @Prop() columns: Array<string | FormatterTableColumn> = [];
  @Prop() rows: FormatterTableRow[] = [];
  @Prop() data?: FormatterTableData;
  @Prop() actionColumnKey = 'accion';
  @Prop() sortable = false;
  @Prop() sortableColumns: string[] = [];
  @Prop() defaultSortColumn = '';
  @Prop() defaultSortDirection: SortDirection = 'asc';
  @Prop() referenceColumnKey = 'referencia';
  @Prop() actionMode: TableActionMode = 'single';
  @Prop() actionButtons: TableActionButtonDefinition[] = [];
  @Prop() dateColumnKeys: string[] = [];
  @Prop() dateFormat: TableDateFormat = 'default';
  @Prop() dateOptions?: TableDateOptions;
  @Prop() moneyColumnKeys: string[] = [];
  @Prop() moneySymbol = '$';
  @Prop() wrapperClass = '';
  @Prop() tableClass = '';
  @Prop() wrapperStyle: Record<string, string> = {};
  @Prop() tableStyle: Record<string, string> = {};

  @State() activeSortColumn = '';
  @State() activeSortDirection: SortDirection = 'asc';

  @Event({ eventName: 'tableActionRequested' }) tableActionRequested!: EventEmitter<TableActionRequestDetail>;

  componentWillLoad() {
    this.activeSortColumn = this.defaultSortColumn;
    this.activeSortDirection = this.defaultSortDirection;
  }

  private getResolvedRows(): FormatterTableRow[] {
    return this.data?.rows ?? this.rows;
  }

  private getResolvedColumns(rows: FormatterTableRow[]): FormatterTableColumn[] {
    const sourceColumns = this.data?.columns ?? this.columns;

    if (sourceColumns.length > 0) {
      return sourceColumns
        .map((column) => {
          if (typeof column === 'string') {
            return { key: column, label: column, sortable: false };
          }

          return {
            key: column.key,
            label: column.label,
            sortable: column.sortable ?? false,
            type: column.type ?? 'default',
            statusOptions: column.statusOptions ?? [],
          };
        })
        .filter((column) => Boolean(column.key));
    }

    return rows[0] ? Object.keys(rows[0]).map((key) => ({ key, label: key, sortable: false })) : [];
  }

  private getCellValue(value: unknown): unknown {
    if (value === null || value === undefined || value === '') {
      return '—';
    }

    if (typeof value === 'boolean') {
      return value ? 'Sí' : 'No';
    }

    if (typeof value === 'string' || typeof value === 'number') {
      return String(value);
    }

    if (Array.isArray(value)) {
      return value.map((item, index) => (
        <span class="table-cell-inline" key={`${index}-${String(item)}`}>
          {this.getCellValue(item)}
        </span>
      ));
    }

    return value;
  }

  private getCellValueByColumn(column: FormatterTableColumn, value: unknown): unknown {
    if (column.type === 'status') {
      const statusDisplay = getStatusDisplay(value, column);

      if (statusDisplay) {
        return (
          <span class={{ 'table-status-tag': true, [`table-status-tag-${statusDisplay.tone}`]: true }}>
            {statusDisplay.value}
          </span>
        );
      }
    }

    if (this.getDateColumnKeys().includes(column.key)) {
      return this.getFormattedDateValue(value);
    }

    if (this.moneyColumnKeys.includes(column.key)) {
      return this.getFormattedMoneyValue(value);
    }

    return this.getCellValue(value);
  }

  private getFormattedMoneyValue(value: unknown): string {
    const parsedMoney = this.parseMoneyValue(value);

    if (parsedMoney === null) {
      return this.getCellValue(value) as string;
    }

    return this.formatMoney(parsedMoney);
  }

  private parseMoneyValue(value: unknown): number | null {
    if (typeof value === 'number' && Number.isFinite(value)) {
      return Math.trunc(value);
    }

    if (typeof value !== 'string') {
      return null;
    }

    const raw = value.trim();
    if (!raw) {
      return null;
    }

    const sanitized = raw.replace(/[^\d,.-]/g, '');
    if (!sanitized) {
      return null;
    }

    const hasDot = sanitized.includes('.');
    const hasComma = sanitized.includes(',');
    let normalized = sanitized;

    if (hasDot && hasComma) {
      const lastDot = sanitized.lastIndexOf('.');
      const lastComma = sanitized.lastIndexOf(',');
      const decimalSeparator = lastDot > lastComma ? '.' : ',';
      const thousandSeparator = decimalSeparator === '.' ? ',' : '.';

      normalized = sanitized.split(thousandSeparator).join('');
      if (decimalSeparator === ',') {
        normalized = normalized.replace(',', '.');
      }
    } else if (hasComma) {
      normalized = /,\d{1,2}$/.test(sanitized) ? sanitized.replace(',', '.') : sanitized.split(',').join('');
    } else if (hasDot) {
      normalized = /\.\d{1,2}$/.test(sanitized) ? sanitized : sanitized.split('.').join('');
    }

    const parsed = Number(normalized);
    if (Number.isNaN(parsed)) {
      return null;
    }

    return Math.trunc(parsed);
  }

  private formatMoney(value: number): string {
    const sign = value < 0 ? '-' : '';
    const absoluteValue = Math.abs(value);
    const thousands = String(absoluteValue).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

    return `${sign}${this.moneySymbol}${thousands}`;
  }

  private getFormattedDateValue(value: unknown): string {
    const parsedDate = this.parseDateValue(value);

    if (!parsedDate) {
      return this.getCellValue(value) as string;
    }

    if (this.getDateFormat() === 'MMMdyyyy') {
      return this.formatSpecialDate(parsedDate);
    }

    if (this.getDateFormat() === 'dd-mmm-yyyy') {
      return this.formatDayMonthYearDate(parsedDate);
    }

    return this.formatDefaultDate(parsedDate);
  }

  private parseDateValue(value: unknown): Date | null {
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
      return value;
    }

    if (typeof value === 'number') {
      const dateFromNumber = new Date(value);
      return Number.isNaN(dateFromNumber.getTime()) ? null : dateFromNumber;
    }

    if (typeof value !== 'string') {
      return null;
    }

    const trimmedValue = value.trim();
    if (!trimmedValue) {
      return null;
    }

    const directDate = new Date(trimmedValue);
    if (!Number.isNaN(directDate.getTime())) {
      return directDate;
    }

    const withoutTimezone = trimmedValue.replace(/\s[A-Z]{2,5}\s(\d{4})$/, ' $1');
    const sanitizedDate = new Date(withoutTimezone);
    if (!Number.isNaN(sanitizedDate.getTime())) {
      return sanitizedDate;
    }

    const rawDateMatch = trimmedValue.match(/^(?:[A-Za-z]{3}\s)?([A-Za-z]{3})\s(\d{1,2})\s\d{2}:\d{2}:\d{2}(?:\s[A-Z]{2,5})?\s(\d{4})$/);
    if (!rawDateMatch) {
      return null;
    }

    const monthIndex = this.monthAbbreviations.indexOf(rawDateMatch[1]);
    if (monthIndex === -1) {
      return null;
    }

    const day = Number(rawDateMatch[2]);
    const year = Number(rawDateMatch[3]);
    const manualDate = new Date(year, monthIndex, day);

    return Number.isNaN(manualDate.getTime()) ? null : manualDate;
  }

  private getDateColumnKeys(): string[] {
    return this.dateOptions?.columnKeys ?? this.dateColumnKeys;
  }

  private getDateFormat(): TableDateFormat {
    return this.dateOptions?.format ?? this.dateFormat;
  }

  private formatDefaultDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    return `${day}/${month}/${year}`;
  }

  private formatSpecialDate(date: Date): string {
    const monthLabel = this.monthLabels[date.getMonth()];
    const day = date.getDate();
    const year = date.getFullYear();

    return `${monthLabel} ${day}, ${year}`;
  }

  private formatDayMonthYearDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const monthLabel = this.monthAbbreviations[date.getMonth()];
    const year = date.getFullYear();

    return `${day}-${monthLabel}-${year}`;
  }

  private hasConfiguredActions(): boolean {
    return this.actionButtons.length > 0;
  }

  private getVisibleActionButtons(): TableActionButtonDefinition[] {
    if (!this.hasConfiguredActions()) {
      return [];
    }

    if (this.actionMode === 'group') {
      return this.actionButtons;
    }

    return this.actionButtons.slice(0, 1);
  }

  private handleActionButtonClick(row: FormatterTableRow, action: TableActionButtonDefinition, event: MouseEvent) {
    const target = event.target as HTMLElement | null;

    if (!target?.closest('button') || action.disabled) {
      return;
    }

    this.tableActionRequested.emit({
      selectedRow: row,
      row,
      reference: row[this.referenceColumnKey],
      referenceKey: this.referenceColumnKey,
      actionKey: action.key,
      actionLabel: action.label,
    });
  }

  private renderActionCellContent(row: FormatterTableRow): unknown {
    if (!this.hasConfiguredActions()) {
      return this.getCellValueByColumn({ key: this.actionColumnKey, label: this.actionColumnKey, type: 'default' }, row[this.actionColumnKey]);
    }

    const actions = this.getVisibleActionButtons();

    if (actions.length === 0) {
      return this.getCellValueByColumn({ key: this.actionColumnKey, label: this.actionColumnKey, type: 'default' }, row[this.actionColumnKey]);
    }

    return (
      <div class={{ 'action-cell-actions': true, 'action-cell-actions-group': this.actionMode === 'group' }}>
        {actions.map((action) => (
          <button
            type="button"
            class={{ 'table-action-button': true, 'table-action-button-group': this.actionMode === 'group' }}
            disabled={action.disabled}
            onClick={(event: MouseEvent) => this.handleActionButtonClick(row, action, event)}
          >
            {action.iconName ? (
              <span class="action-button-icon">
                {renderCustomTableIcon({
                  name: action.iconName,
                  color: action.iconColor || 'currentColor',
                  size: 28,                  
                  text: action.iconText,
                })}
              </span>
            ) : null}
            {action.label ? <span class="action-button-label">{action.label}</span> : null}
          </button>
        ))}
      </div>
    );
  }

  private isColumnSortable(column: FormatterTableColumn): boolean {
    if (!this.sortable) {
      return false;
    }

    if (column.key === this.actionColumnKey) {
      return false;
    }

    if (this.sortableColumns.length > 0) {
      return this.sortableColumns.includes(column.key);
    }

    return column.sortable === true;
  }

  private handleSort(columnKey: string, column: FormatterTableColumn) {
    if (!this.isColumnSortable(column)) {
      return;
    }

    const nextDirection: SortDirection = this.activeSortColumn === columnKey && this.activeSortDirection === 'asc' ? 'desc' : 'asc';
    this.activeSortColumn = columnKey;
    this.activeSortDirection = nextDirection;
  }

  private getOrderedRows(rows: FormatterTableRow[]): FormatterTableRow[] {
    if (!this.sortable || !this.activeSortColumn) {
      return rows;
    }

    return sortRows(rows, this.activeSortColumn, this.activeSortDirection, this.getDateColumnKeys(), this.getResolvedColumns(rows));
  }

  render() {
    const rows = this.getResolvedRows();
    const columns = this.getResolvedColumns(rows);
    const orderedRows = this.getOrderedRows(rows);
    const hasRows = orderedRows.length > 0;

    return (
      <div class={this.wrapperClass || undefined} style={this.wrapperStyle}>
        {this.tableTitle ? <div class="table-title">{this.tableTitle}</div> : null}

        <div class="table-shell">
          <table class={{ 'formatter-table': true, [this.tableClass]: Boolean(this.tableClass) }} style={this.tableStyle}>
            <thead>
              <tr>
                {columns.map((column) => {
                  const isSortable = this.isColumnSortable(column);
                  const isActive = this.activeSortColumn === column.key;

                  return (
                    <th scope="col" key={column.key}>
                      {isSortable ? (
                        <button
                          type="button"
                          class={{ 'sort-button': true, 'is-active': isActive }}
                          onClick={() => this.handleSort(column.key, column)}
                        >
                          <span>{column.label}</span>
                          <span class="sort-indicator">
                            {renderCustomTableIcon({
                              name: 'arrow-up-down',
                              color: isActive ? '#cc0e35' : 'currentColor',
                              size: 18,
                              strokeWidth: 1.85,
                            })}
                          </span>
                        </button>
                      ) : (
                        <span>{column.label}</span>
                      )}
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {hasRows ? (
                orderedRows.map((row, index) => (
                  <tr class={{ 'is-striped': index % 2 === 1 }} key={`row-${index}`}>
                    {columns.map((column) => (
                      <td key={`row-${index}-${column.key}`}>
                        {column.key === this.actionColumnKey
                          ? this.renderActionCellContent(row)
                          : this.getCellValueByColumn(column, row[column.key])}
                      </td>
                    ))}
                  </tr>
                ))
              ) : (
                <tr class="empty-row">
                  <td colSpan={columns.length || 1}>{this.emptyText}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}
