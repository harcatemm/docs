// biome-ignore lint/correctness/noUnusedImports: Stencil classic JSX requires `h` in scope
import { h } from '@stencil/core';

export type CustomTableIconName = 'arrow-up-down' | 'file';

export interface CustomTableIconProps {
  name: CustomTableIconName;
  color?: string;
  strokeColor?: string;
  size?: number | string;
  strokeWidth?: number | string;
  text?: string;
}

export function renderCustomTableIcon(props: CustomTableIconProps) {
  const { name, color, strokeColor, text, size = 18, strokeWidth = 2 } = props;
  const stroke = color || strokeColor || 'currentColor';
  const iconSize = typeof size === 'number' ? size : Number(size) || 18;
  const iconStrokeWidth = typeof strokeWidth === 'number' ? strokeWidth : Number(strokeWidth) || 2;

  switch (name) {
    case 'arrow-up-down':
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width={iconSize}
          height={iconSize}
          viewBox="0 0 24 24"
          fill="none"
          stroke={stroke}
          stroke-width={iconStrokeWidth}
          stroke-linecap="round"
          stroke-linejoin="round"
          class="lucide lucide-arrow-up-down-icon lucide-arrow-up-down"
          aria-hidden="true"
          focusable="false"
        >
          <path d="m21 16-4 4-4-4" />
          <path d="M17 20V4" />
          <path d="m3 8 4-4 4 4" />
          <path d="M7 4v16" />
        </svg>
      );
    case 'file':
      return (
        <svg
          width={iconSize}
          height={iconSize}
          viewBox="0 0 455 533"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
          focusable="false"
        >
          <rect width="455" height="533" fill="none" />
          <g opacity="0.9" clip-path="url(#clip0_3311_4)">
            <path d="M64 0C28.7 0 0 28.7 0 64V448C0 483.3 28.7 512 64 512H320C355.3 512 384 483.3 384 448V170.5C384 153.5 377.3 137.2 365.3 125.2L258.7 18.7C246.7 6.7 230.5 0 213.5 0H64ZM325.5 176H232C218.7 176 208 165.3 208 152V58.5L325.5 176Z" 
                fill={stroke} 
            />
          </g>
          <rect x="155" y="365" width="325" height="150" rx="40" fill="#fff" />
          <text
            fill={stroke}
            stroke={stroke}
            style={{ whiteSpace: 'pre' }}
            stroke-width="8"
            stroke-linejoin="bevel"
            xml-space="preserve"
            font-family="Inter"
            font-size="155"
            letter-spacing="0em"
          >
            <tspan x="173" y="510.045">{text}</tspan>
          </text>
          <defs>
            <clipPath id="clip0_3311_4">
              <rect width="384" height="512" fill="none" />
            </clipPath>
          </defs>
        </svg>
      );
    default:
      return null;
  }
}
