import { Component, h, Prop } from '@stencil/core';

@Component({
  tag: 'app-container',
  styleUrl: 'container.css',
  shadow: false,
})
export class ContainerComponent {
  @Prop() containerTitle = 'Contenedor estático';

  render() {
    return (
      <div class="container-shell">
        <div class="container-header">
          <h2 class="container-title">{this.containerTitle}</h2>          
        </div>
        <div class="container-body">
          <slot></slot>
        </div>
      </div>
    );
  }
}
