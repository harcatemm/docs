// biome-ignore lint/correctness/noUnusedImports: Stencil classic JSX requires `h` in scope
import { h } from '@stencil/core';

export type AddressFormatterIconName = 'search' | 'location' | 'barcode-read' | 'check' | 'left-arrow' | 'right-arrow' | 'pencil';

export interface AddressFormatterIconProps {
  name: AddressFormatterIconName;
  color?: string;
  size?: number;
  strokeWidth?: number;
}

export function renderAddressFormatterIcon(props: AddressFormatterIconProps) {
  const { name, color, size = 20, strokeWidth = 1.75 } = props;
  const stroke = color || 'currentColor';

  switch (name) {
    case 'search':
      return (
        <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke={stroke} stroke-width={strokeWidth} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <circle cx="11" cy="11" r="7" />
          <path d="m20 20-3.5-3.5" />
        </svg>
      );
    case 'location':
      return (
        <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke={stroke} stroke-width={strokeWidth} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0" fill={stroke} />
          <circle cx="12" cy="10" r="3" fill="#fff" stroke={stroke} />
        </svg>
      );
    case 'barcode-read':
      return (
        <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke={stroke} stroke-width={strokeWidth} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 7V5a2 2 0 0 1 2-2h2" />
          <path d="M17 3h2a2 2 0 0 1 2 2v2" />
          <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
          <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
          <path d="M8 7v10" />
          <path d="M12 7v10" />
          <path d="M17 7v10" />
        </svg>
      );
    case 'check':
      return (
        <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke={stroke} stroke-width={strokeWidth} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="10" />
          <path d="m9 12 2 2 4-4" />
        </svg>
      );
    case 'left-arrow':
      return (
        <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke={stroke} stroke-width={strokeWidth} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <path d="m12 19-7-7 7-7" />
          <path d="M19 12H5" />
        </svg>
      );
    case 'right-arrow':
      return (
        <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke={stroke} stroke-width={strokeWidth} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <path d="M5 12h14" />
          <path d="m12 5 7 7-7 7" />
        </svg>
      );
    case 'pencil':
      return (
        <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke={stroke} stroke-width={strokeWidth} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" />
          <path d="m15 5 4 4" />
        </svg>
      );
    default:
      return null;
  }
}
