export interface AddressFields {
  tipoVia: string;
  numVia: string;
  prefijo: string;
  bis: string;
  letraCompl: string;
  cuadranteVia: string;
  numGen: string;
  letraGen: string;
  placa: string;
  cuadrantePlaca: string;
}

export type AddressFieldInputType = 'text' | 'select';

export interface SelectOption {
  label: string;
  value: string;
}

export const viaTypeOptions: SelectOption[] = [
  { label: '--', value: '' },
  { label: 'CL', value: 'CL' },
  { label: 'KR', value: 'KR' },
  { label: 'DG', value: 'DG' },
  { label: 'TV', value: 'TV' },
  { label: 'AV', value: 'AV' },
  { label: 'AC', value: 'AC' },
  { label: 'AK', value: 'AK' },
];

export const quadrantOptions: SelectOption[] = [
  { label: '--', value: '' },
  { label: 'Norte', value: 'NORTE' },
  { label: 'Sur', value: 'SUR' },
  { label: 'Este', value: 'ESTE' },
  { label: 'Oeste', value: 'OESTE' },
];

export const additionalAddressOptions: SelectOption[] = [
  { label: '--', value: '' },
  { label: 'BIS', value: 'BIS' },  
];