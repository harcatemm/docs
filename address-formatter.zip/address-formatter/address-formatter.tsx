import { Component, h, Prop, State, Event, EventEmitter, Method } from '@stencil/core';
import { AddressFields, AddressFieldInputType, SelectOption, quadrantOptions, additionalAddressOptions, viaTypeOptions } from './address-formatter.models';
import { renderAddressFormatterIcon } from './address-formatter-icon';

export interface AddressFormatterStatus {
  isAddressFormated: boolean;
  formattedAddress: string;
}

@Component({
  tag: 'address-formatter',
  styleUrl: 'address-formatter.css',
  shadow: true,
})
export class AddressFormatter {
  @Prop() placeholder = '';
  @Prop() buttonText = '';
  @Prop() initialValue = '';
  @Prop() showSteps = true;
  @Prop({ reflect: true }) theme: 'light' | 'dark' = 'light';
  @Prop() width = '100%';
  @Prop() maxWidth = '760px';

  private readonly uiText = {
    placeholder: 'Ej: CL 123 45 67',
    buttonText: 'Convertir',
    addressTitle: 'Dirección del predio',
    emptyAddressError: 'Ingrese una dirección para convertir.',
    previewLabel: 'Dirección:',
    previewErrorMessage: 'Formato de dirección incorrecto',
    bisPreviewValue: 'BIS',
    convertTabLabel: 'Ingresar dirección',
    buildTabLabel: 'Control',
    previewPlaceholder: '—',
    groupTitles: {
      primary: 'Vía Principal',
      secondary: 'Vía Secundaria',
    },
    fieldLabels: {
      tipoVia: 'Tipo',
      numVia: 'N°',
      prefijo: 'Letra',
      bis: 'Bis',
      letraCompl: 'Letra',
      cuadranteVia: 'Cuadr.',
      numGen: 'Generación',
      letraGen: 'Letra',
      placa: 'Placa',
      cuadrantePlaca: 'Cuadr.',
    },
    fieldPlaceholders: {
      numVia: 'N°',
      prefijo: 'A',
      letraCompl: 'B',
      numGen: 'N°',
      letraGen: 'C',
      placa: 'N°',
    },
    combinedSeparator: '—',
  };

  @State() inputValue = '';
  @State() fields: AddressFields = {
    tipoVia: '',
    numVia: '',
    prefijo: '',
    bis: '',
    letraCompl: '',
    cuadranteVia: '',
    numGen: '',
    letraGen: '',
    placa: '',
    cuadrantePlaca: '',
  };
  @State() preview = this.uiText.previewPlaceholder;
  @State() error = '';
  @State() activeTab: 'convert' | 'build' = 'convert';
  @State() showFormatErrorMessage = false;

  @Event({ eventName: 'addressFormatterStatusChanged', bubbles: true, composed: true })
  addressFormatterStatusChanged!: EventEmitter<AddressFormatterStatus>;

  @Method()
  async getStatus(): Promise<AddressFormatterStatus> {
    return this.getCurrentStatus();
  }

  componentWillLoad() {
    this.inputValue = this.initialValue;
    if (this.initialValue.trim()) {
      this.syncFromText(this.initialValue);
    } else {
      this.emitStatusChange();
    }
  }

  private getCurrentStatus(): AddressFormatterStatus {
    return {
      isAddressFormated: this.hasBuilderStarted() && this.isMinimumControlComplete(),
      formattedAddress: this.preview || this.buildPreview(this.fields),
    };
  }

  private emitStatusChange() {
    this.addressFormatterStatusChanged.emit(this.getCurrentStatus());
  }

  private normalizeText(text: string): string {
    return text
      .toUpperCase()
      .trim()
      .replace(/#/g, ' ')
      .replace(/-/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  private parsearDireccion(texto: string): AddressFields {
    const dir = this.normalizeText(texto);
    const campos: AddressFields = {
      tipoVia: '',
      numVia: '',
      prefijo: '',
      bis: '',
      letraCompl: '',
      cuadranteVia: '',
      numGen: '',
      letraGen: '',
      placa: '',
      cuadrantePlaca: '',
    };

    const partes = dir.split(' ');
    const TIPOS_VIA: Record<string, string> = {
      CL: 'CL', CALLE: 'CL', CAL: 'CL', CLL: 'CL', C : 'CL',
      KR: 'KR', CARRERA: 'KR', K: 'KR', CAR: 'KR', CA: 'KR', KA: 'KR', CRA: 'KR',
      DG: 'DG', DIAGONAL: 'DG', D: 'DG',
      TV: 'TV', TRANSVERSAL: 'TV', T: 'TV',
      AV: 'AV', AVENIDA: 'AV', A: 'AV',
      AC: 'AC', AUTOPISTA: 'AC',
      AK: 'AK',
    };

    const CUADRANTES: Record<string, string> = {
      NORTE: 'NORTE', NTE: 'NORTE', N: 'NORTE',
      SUR: 'SUR', S: 'SUR',
      ESTE: 'ESTE', E: 'ESTE',
      OESTE: 'OESTE', O: 'OESTE',
    };

    let idx = 0;
    let tipoEncontrado: string | null = null;

    for (let i = 0; i < Math.min(2, partes.length); i++) {
      const p = partes[i].replace(/[^A-Z]/g, '');
      if (TIPOS_VIA[p] || TIPOS_VIA[partes[i]]) {
        tipoEncontrado = TIPOS_VIA[p] || TIPOS_VIA[partes[i]];
        idx = i + 1;
        break;
      }
    }

    campos.tipoVia = tipoEncontrado || '';

    const tokens = partes.slice(idx).filter((t) => t !== 'NO' && t !== 'NUM' && t !== 'NUMERO' && t !== 'NÚMERO');
    let ti = 0;

    if (ti < tokens.length) {
      const match = tokens[ti].match(/^(\d+)([A-Z]?)$/);
      if (match) {
        campos.numVia = match[1];
        campos.prefijo = match[2] || '';
        ti++;
      }
    }

    if (ti < tokens.length && tokens[ti] === 'BIS') {
      campos.bis = 'BIS';
      ti++;
    }

    if (ti < tokens.length && /^[A-Z]$/.test(tokens[ti])) {
      campos.letraCompl = tokens[ti];
      ti++;
    }

    if (ti < tokens.length && CUADRANTES[tokens[ti]]) {
      campos.cuadranteVia = CUADRANTES[tokens[ti]];
      ti++;
    }

    if (ti < tokens.length) {
      const match = tokens[ti].match(/^(\d+)([A-Z]?)$/);
      if (match) {
        campos.numGen = match[1];
        campos.letraGen = match[2] || '';
        ti++;
      }
    }

    if (ti < tokens.length) {
      const match = tokens[ti].match(/^(\d+)([A-Z]?)$/);
      if (match) {
        campos.placa = match[1];
        if (match[2]) campos.letraGen = campos.letraGen || match[2];
        ti++;
      }
    }

    if (ti < tokens.length && CUADRANTES[tokens[ti]]) {
      campos.cuadrantePlaca = CUADRANTES[tokens[ti]];
    }

    return campos;
  }

  private buildPreview(c: AddressFields): string {
    const parts: string[] = [c.tipoVia];
    if (c.numVia) parts.push(c.numVia + c.prefijo);
    if (c.bis) parts.push(this.uiText.bisPreviewValue);
    if (c.letraCompl) parts.push(c.letraCompl);
    if (c.cuadranteVia) parts.push(this.toTitleCase(c.cuadranteVia));

    if (c.numGen || c.placa) {
      const generalNumber = c.numGen ? `${c.numGen}${c.letraGen}` : '';
      if (generalNumber) parts.push(generalNumber);
      if (c.placa) parts.push(c.placa);
    }

    if (c.cuadrantePlaca) parts.push(this.toTitleCase(c.cuadrantePlaca));

    return parts.join(' ') || this.uiText.previewPlaceholder;
  }

  private toTitleCase(value: string): string {
    return value.charAt(0) + value.slice(1).toLowerCase();
  }

  private resetBuilderState() {
    this.fields = {
      tipoVia: '',
      numVia: '',
      prefijo: '',
      bis: '',
      letraCompl: '',
      cuadranteVia: '',
      numGen: '',
      letraGen: '',
      placa: '',
      cuadrantePlaca: '',
    };
    this.preview = '—';
    this.error = '';
    this.showFormatErrorMessage = false;
  }

  private syncFromText(text: string) {
    if (!text.trim()) {
      this.resetBuilderState();
      return;
    }

    const campos = this.parsearDireccion(text);
    this.fields = campos;
    this.preview = this.buildPreview(campos);
    this.error = '';
    this.emitStatusChange();
  }

  private hasBuilderData(): boolean {
    return Object.values(this.fields).some((value) => typeof value === 'string' && value.trim().length > 0);
  }

  private handleConvert = () => {
    const texto = this.inputValue.trim();
    if (!texto) {
      if (this.activeTab === 'convert' && !this.isMinimumControlComplete() && this.hasBuilderData()) {
        this.activeTab = 'build';
        this.preview = this.buildPreview(this.fields);
        this.error = '';
        this.showFormatErrorMessage = false;
        this.emitStatusChange();
        return;
      }

      this.error = this.uiText.emptyAddressError;
      this.preview = this.uiText.previewPlaceholder;
      this.showFormatErrorMessage = false;
      this.emitStatusChange();
      return;
    }

    if (this.activeTab === 'convert') {
      const parsed = this.parsearDireccion(texto);
      this.fields = parsed;
      this.preview = this.buildPreview(parsed);
      this.error = '';
      this.inputValue = texto;
      this.showFormatErrorMessage = texto.length > 0 && !this.isMinimumControlComplete();
      this.emitStatusChange();
      return;
    }

    this.syncFromText(texto);
    this.showFormatErrorMessage = !this.isMinimumControlComplete();
    this.emitStatusChange();
  };

  private handleTextInput = (event: Event) => {
    const target = event.target as HTMLTextAreaElement;
    this.inputValue = target.value;
    this.showFormatErrorMessage = false;
    if (!target.value.trim()) {
      this.resetBuilderState();
    } else {
      this.emitStatusChange();
    }
  };

  private normalizeFieldValue(field: keyof AddressFields, value: string): string {
    if (field === 'numVia' || field === 'numGen' || field === 'placa') {
      return value.replace(/\D/g, '');
    }

    if (field === 'prefijo' || field === 'letraCompl' || field === 'letraGen') {
      return value.replace(/[^A-ZÁÉÍÓÚÑ]/gi, '').slice(0, 1);
    }

    if (field !== 'tipoVia') {
      return value.toUpperCase();
    }

    return value;
  }

  private syncBuilderProgressToInput() {
    const nextValue = this.buildPreview(this.fields);
    this.inputValue = nextValue === '—' ? '' : nextValue;
  }

  private handleFieldChange = (field: keyof AddressFields, event: Event) => {
    const target = event.target as HTMLInputElement | HTMLSelectElement;
    const value = this.normalizeFieldValue(field, target.value);

    this.fields = {
      ...this.fields,
      [field]: value,
    };

    this.preview = this.buildPreview(this.fields);
    this.error = '';
    this.syncBuilderProgressToInput();
    this.emitStatusChange();
  };

  private switchTab(tab: 'convert' | 'build') {
    this.activeTab = tab;
    if (tab === 'convert') {
      this.preview = this.buildPreview(this.fields);
      this.syncBuilderProgressToInput();
      this.showFormatErrorMessage = this.inputValue.trim().length > 0 && !this.isMinimumControlComplete();
      this.emitStatusChange();
    }
  }

  private isControlFilled(value: string | undefined): boolean {
    return typeof value === 'string' ? value.trim().length > 0 : !!value;
  }

  private isMinimumControlComplete(): boolean {
    return Boolean(
      this.fields.tipoVia &&
      this.fields.numVia &&
      this.fields.numGen &&
      this.fields.placa,
    );
  }

  private hasBuilderStarted(): boolean {
    return Boolean(
      this.fields.tipoVia ||
      this.fields.numVia ||
      this.fields.numGen ||
      this.fields.placa
    );
  }

  private shouldShowFormatError(): boolean {
    if (this.activeTab === 'build') {
      return this.hasBuilderStarted() && !this.isMinimumControlComplete();
    }

    return this.showFormatErrorMessage && this.inputValue.trim().length > 0 && !this.isMinimumControlComplete();
  }

  private isNumericField(field: keyof AddressFields): boolean {
    return field === 'numVia' || field === 'numGen' || field === 'placa';
  }

  private isLetterField(field: keyof AddressFields): boolean {
    return field === 'prefijo' || field === 'letraCompl' || field === 'letraGen';
  }

  private handleNumericKeyDown = (field: keyof AddressFields, event: KeyboardEvent) => {
    if (!this.isNumericField(field)) {
      return;
    }

    if (event.ctrlKey || event.metaKey) {
      return;
    }

    const allowedKeys = ['Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight', 'Home', 'End', 'Enter', 'Escape'];
    if (allowedKeys.includes(event.key) || event.key.length !== 1) {
      return;
    }

    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
    }
  };

  private handleNumericPaste = (field: keyof AddressFields, event: ClipboardEvent) => {
    if (!this.isNumericField(field)) {
      return;
    }

    const pastedText = event.clipboardData?.getData('text') ?? '';
    if (!/^\d*$/.test(pastedText)) {
      event.preventDefault();
    }
  };

  private handleLetterKeyDown = (field: keyof AddressFields, event: KeyboardEvent) => {
    if (!this.isLetterField(field)) {
      return;
    }

    if (event.ctrlKey || event.metaKey) {
      return;
    }

    const allowedKeys = ['Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight', 'Home', 'End', 'Enter', 'Escape'];
    if (allowedKeys.includes(event.key) || event.key.length !== 1) {
      return;
    }

    if (!/^[A-Z]$/i.test(event.key)) {
      event.preventDefault();
    }
  };

  private handleLetterPaste = (field: keyof AddressFields, event: ClipboardEvent) => {
    if (!this.isLetterField(field)) {
      return;
    }

    const pastedText = event.clipboardData?.getData('text') ?? '';
    if (!/^[A-Z]*$/i.test(pastedText)) {
      event.preventDefault();
    }
  };

  private renderField(
    label: string,
    placeholder: string = '',
    field: keyof AddressFields,
    type: AddressFieldInputType = 'text',
    options: SelectOption[] = [],
    extraClass = '',
  ) {
    const value = this.fields[field];

    if (type === 'select') {
      const selectOptions = options.length > 0 ? options : viaTypeOptions;

      return (
        <label class={{ field: true, [extraClass]: !!extraClass }}>
          <span>{label}</span>
          <select
            class={{ 'has-value': this.isControlFilled(value) }}
            ref={(el) => {
              if (el && el.value !== (value || '')) {
                el.value = value || '';
              }
            }}
            onInput={(event) => this.handleFieldChange(field, event)}
          >
            {selectOptions.map((option) => (
              <option value={option.value}>{option.label}</option>
            ))}
          </select>
        </label>
      );
    }

    return (
      <label class={{ field: true, [extraClass]: !!extraClass }}>
        <span>{label}</span>
        <input
          class={{ 'has-value': this.isControlFilled(value) }}
          value={value}
          inputMode={this.isLetterField(field) ? 'text' : 'numeric'}
          pattern={this.isLetterField(field) ? '[A-Za-z]*' : '[0-9]*'}
          onInput={(event) => this.handleFieldChange(field, event)}
          onKeyDown={(event) => {
            if (this.isLetterField(field)) {
              this.handleLetterKeyDown(field, event);
            } else {
              this.handleNumericKeyDown(field, event);
            }
          }}
          onPaste={(event) => {
            if (this.isLetterField(field)) {
              this.handleLetterPaste(field, event);
            } else {
              this.handleNumericPaste(field, event);
            }
          }}
          placeholder={placeholder}
        />
      </label>
    );
  }

  private getPreviewCardClasses() {
    return {
      'preview-card': true,
      'preview-card-valid': this.hasBuilderStarted() && this.isMinimumControlComplete(),
      'preview-card-invalid': this.hasBuilderStarted() && !this.isMinimumControlComplete(),
    };
  }

  private renderConvertTab() {
    return (
      <div class="tab-panel">
        <div class="convert-controls">
          <label class="full-width">
            <span class="titles" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem' }}>
              {renderAddressFormatterIcon({ name: 'location', color: '#000000', size: 18, strokeWidth: 1.75 })}
              <span>{this.uiText.addressTitle}</span>
            </span>
            <input
              value={this.inputValue}
              onInput={this.handleTextInput}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  event.preventDefault();
                  this.handleConvert();
                }
              }}
              placeholder={this.placeholder || this.uiText.placeholder}
            />
          </label>

          <button type="button" class="convert-button" onClick={this.handleConvert}>
            {this.buttonText || this.uiText.buttonText}
          </button>
        </div>

        {this.error ? <p class="error">{this.error}</p> : null}
      </div>
    );
  }

  private renderBuildTab() {
    return (
      <div class="tab-panel">
        <div class="group-title">{this.uiText.groupTitles.primary}</div>
        <div class="control-group">
          <div class="main-grid-wrapper">
            <div class="main-grid-column">
              <div class="main-grid-placeholder"></div>
            </div>
            <div class="main-grid-column">
              <div class="grid compact-grid primary-group-grid">
                {this.renderField(this.uiText.fieldLabels.tipoVia, '', 'tipoVia', 'select', [], 'field-custom')}
                {this.renderField(this.uiText.fieldLabels.numVia, this.uiText.fieldPlaceholders.numVia,  'numVia', 'text', [], 'field-number-plate')}
                {this.renderField(this.uiText.fieldLabels.prefijo, this.uiText.fieldPlaceholders.prefijo, 'prefijo', 'text', [], 'field-letter')}
                {this.renderField(this.uiText.fieldLabels.bis, '', 'bis', 'select', additionalAddressOptions, 'field-additional')}
                {this.renderField(this.uiText.fieldLabels.letraCompl, this.uiText.fieldPlaceholders.letraCompl, 'letraCompl', 'text', [], 'field-letter')}
                {this.renderField(this.uiText.fieldLabels.cuadranteVia, '', 'cuadranteVia', 'select', quadrantOptions, 'field-quadrant')}
              </div>
            </div>
          </div>
        </div>

        <div class="group-title">{this.uiText.groupTitles.secondary}</div>
        <div class="control-group">
          <div class="main-grid-wrapper">
            <div class="main-grid-column">
              <div class="main-grid-placeholder"></div>
            </div>
            <div class="main-grid-column">
              <div class="grid compact-grid secondary-group-grid">
                <label class="field field-inline-guide field-number-plate">
                  <span>{this.uiText.fieldLabels.numGen}</span>
                  <div class="inline-input-group">
                    <span class="inline-guide">{this.uiText.fieldLabels.numVia}</span>
                    <input
                      class={{ 'has-value': this.isControlFilled(this.fields.numGen) }}
                      value={this.fields.numGen}
                      inputMode="numeric"
                      pattern="[0-9]*"
                      onInput={(event) => this.handleFieldChange('numGen', event)}
                      onKeyDown={(event) => this.handleNumericKeyDown('numGen', event)}
                      onPaste={(event) => this.handleNumericPaste('numGen', event)}
                      placeholder={this.uiText.fieldPlaceholders.numGen}
                    />
                  </div>
                </label>

                <div class="field field-combined">
                  <div class="combined-inputs">
                    <label class="field mini-field field-letter">
                      <span>{this.uiText.fieldLabels.letraGen}</span>
                      <input
                        class={{ 'has-value': this.isControlFilled(this.fields.letraGen) }}
                        value={this.fields.letraGen}
                        inputMode="text"
                        pattern="[A-Za-z]*"
                        onInput={(event) => this.handleFieldChange('letraGen', event)}
                        onKeyDown={(event) => this.handleLetterKeyDown('letraGen', event)}
                        onPaste={(event) => this.handleLetterPaste('letraGen', event)}
                        placeholder={this.uiText.fieldPlaceholders.letraGen}
                      />
                    </label>

                    <span class="combined-separator">{this.uiText.combinedSeparator}</span>

                    <label class="field mini-field field-number-plate">
                      <span>{this.uiText.fieldLabels.placa}</span>
                      <input
                        class={{ 'has-value': this.isControlFilled(this.fields.placa) }}
                        value={this.fields.placa}
                        inputMode="numeric"
                        pattern="[0-9]*"
                        onInput={(event) => this.handleFieldChange('placa', event)}
                        onKeyDown={(event) => this.handleNumericKeyDown('placa', event)}
                        onPaste={(event) => this.handleNumericPaste('placa', event)}
                        placeholder={this.uiText.fieldPlaceholders.placa}
                      />
                    </label>
                  </div>
                </div>

                {this.renderField(this.uiText.fieldLabels.cuadrantePlaca, '', 'cuadrantePlaca', 'select', quadrantOptions, 'field-quadrant')}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  private renderPreviewCard() {
    return (
      <div class={this.getPreviewCardClasses()}>
        <div class="preview-main">
          <span class="preview-final-address">{this.uiText.previewLabel}</span>
          <div class="preview-value">{this.preview}</div>
        </div>
        {this.shouldShowFormatError() ? <span class="preview-value-error">{this.uiText.previewErrorMessage}</span> : null}
      </div>
    );
  }

  private renderTabLabel(iconName: 'pencil' | 'barcode-read', label: string, isActive: boolean) {
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
        {renderAddressFormatterIcon({
          name: iconName,
          color: isActive ? 'var(--color-primary)' : '#8a8a8a',
          size: 18,
          strokeWidth: 1.75,
        })}
        <span>{label}</span>
      </span>
    );
  }

  render() {
    return (
      <div
        class={{ 'address-formatter': true, [`theme-${this.theme}`]: true }}
        style={{ width: this.width, maxWidth: this.maxWidth, margin: '0 auto' }}
      >
        <section class="card">
          <div class="tabs">
            <button
              type="button"
              class={{ tab: true, active: this.activeTab === 'convert' }}
              onClick={() => this.switchTab('convert')}
            >
              {this.renderTabLabel('pencil', this.uiText.convertTabLabel, this.activeTab === 'convert')}
            </button>
            <button
              type="button"
              class={{ tab: true, active: this.activeTab === 'build' }}
              onClick={() => this.switchTab('build')}
            >
              {this.renderTabLabel('barcode-read', this.uiText.buildTabLabel, this.activeTab === 'build')}
            </button>
          </div>

          {this.activeTab === 'convert' ? this.renderConvertTab() : null}

          {this.activeTab === 'build' ? this.renderBuildTab() : null}

          {this.renderPreviewCard()}
        </section>
      </div>
    );
  }
}
