import { Component, Event, EventEmitter, h, Prop, State, Watch } from '@stencil/core';

export interface CustomRadioOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface CustomRadioSelection {
  value: string;
  label: string;
  option: CustomRadioOption;
}

@Component({
  tag: 'custom-radio',
  styleUrl: 'custom-radio.css',
  shadow: true,
})
export class CustomRadio {
  @Prop() options: CustomRadioOption[] = [];

  @Prop({ mutable: true, reflect: true }) value = '';

  @Prop() name = 'custom-radio-group';

  @Prop() orientation: 'horizontal' | 'vertical' = 'vertical';

  @Prop() legend = '';

  @Prop() borderColor = '#cbd5e1';

  @Prop() selectedBorderColor = '#2563eb';

  @Prop() innerColor = '#ffffff';

  @Prop() selectedInnerColor = '#2563eb';

  @Prop() labelColor = '#111827';

  @State() currentValue = '';

  @Event({ eventName: 'customRadioSelection', bubbles: true, composed: true })
  customRadioSelection!: EventEmitter<CustomRadioSelection>;

  componentWillLoad() {
    this.syncSelection(this.value);
  }

  @Watch('value')
  handleValueChange(newValue: string, oldValue: string) {
    if (newValue !== oldValue) {
      this.syncSelection(newValue);
    }
  }

  @Watch('options')
  handleOptionsChange() {
    this.syncSelection(this.value);
  }

  private syncSelection(nextValue: string | undefined) {
    const normalizedValue = nextValue ?? '';
    const hasMatchingOption = this.options.some((option) => option.value === normalizedValue);

    this.currentValue = hasMatchingOption ? normalizedValue : '';

    if (this.value !== normalizedValue) {
      this.value = normalizedValue;
    }
  }

  private handleOptionSelect = (option: CustomRadioOption, event?: Event) => {
    event?.stopPropagation();

    if (option.disabled) {
      return;
    }

    this.currentValue = option.value;
    this.value = option.value;

    this.customRadioSelection.emit({
      value: option.value,
      label: option.label,
      option,
    });
  };

  private renderOption(option: CustomRadioOption) {
    const isSelected = this.currentValue === option.value;

    return (
      <label
        class={{
          'radio-option': true,
          'is-selected': isSelected,
          'is-disabled': Boolean(option.disabled),
        }}
        onClick={(event: Event) => this.handleOptionSelect(option, event)}
      >
        <span class="radio-input-wrap">
          <input
            class="radio-input"
            type="radio"
            name={this.name}
            value={option.value}
            checked={isSelected}
            disabled={Boolean(option.disabled)}
            onChange={() => this.handleOptionSelect(option)}
          />
          <span class={{ 'radio-control': true, 'is-selected': isSelected }} />
        </span>
        <span class="radio-label">{option.label}</span>
      </label>
    );
  }

  render() {
    const options = Array.isArray(this.options) ? this.options : [];
    const style: Record<string, string> = {
      '--radio-border-color': this.borderColor,
      '--radio-selected-border-color': this.selectedBorderColor,
      '--radio-inner-color': this.innerColor,
      '--radio-selected-inner-color': this.selectedInnerColor,
      '--radio-label-color': this.labelColor,
    };

    return (
      <div
        class={{ 'radio-group': true, 'is-horizontal': this.orientation === 'horizontal' }}
        style={style}
      >
        {this.legend ? <span class="radio-legend">{this.legend}</span> : null}
        <div class={{ 'radio-options': true, 'is-horizontal': this.orientation === 'horizontal' }}>
          {options.map((option) => this.renderOption(option))}
        </div>
      </div>
    );
  }
}
