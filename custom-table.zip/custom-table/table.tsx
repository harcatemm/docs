import { Component, Event, EventEmitter, h, Prop } from '@stencil/core';

export interface FormatterTableRow {
  [key: string]: string | number | boolean | null | undefined | unknown;
}

export interface FormatterTableColumn {
  key: string;
  label: string;
}

export interface FormatterTableData {
  columns?: Array<string | FormatterTableColumn>;
  rows?: FormatterTableRow[];
}

export interface TableActionRequestDetail {
  selectedRow: FormatterTableRow;
  row: FormatterTableRow;
  reference: unknown;
  referenceKey: string;
}

export type TableDateFormat = 'default' | 'MMMdyyyy';

export interface TableDateOptions {
  columnKeys: string[];
  format?: TableDateFormat;
}

@Component({
  tag: 'custom-table',
  styleUrl: 'table.css',
  shadow: true,
})
export class CustomTable {
  private readonly monthAbbreviations = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  private readonly monthLabels = ['Ene.', 'Feb.', 'Mar.', 'Abr.', 'May.', 'Jun.', 'Jul.', 'Ago.', 'Sep.', 'Oct.', 'Nov.', 'Dic.'];

  @Prop() tableTitle = '';
  @Prop() emptyText = 'Sin registros';
  @Prop() columns: Array<string | FormatterTableColumn> = [];
  @Prop() rows: FormatterTableRow[] = [];
  @Prop() data?: FormatterTableData;
  @Prop() actionColumnKey = 'accion';
  @Prop() referenceColumnKey = 'referencia';
  @Prop() dateColumnKeys: string[] = [];
  @Prop() dateFormat: TableDateFormat = 'default';
  @Prop() dateOptions?: TableDateOptions;
  @Prop() moneyColumnKeys: string[] = [];
  @Prop() moneySymbol = '$';
  @Prop() wrapperClass = '';
  @Prop() tableClass = '';
  @Prop() wrapperStyle: Record<string, string> = {};
  @Prop() tableStyle: Record<string, string> = {};

  @Event({ eventName: 'tableActionRequested' }) tableActionRequested!: EventEmitter<TableActionRequestDetail>;

  private getResolvedRows(): FormatterTableRow[] {
    return this.data?.rows ?? this.rows;
  }

  private getResolvedColumns(rows: FormatterTableRow[]): FormatterTableColumn[] {
    const sourceColumns = this.data?.columns ?? this.columns;

    if (sourceColumns.length > 0) {
      return sourceColumns
        .map((column) => {
        if (typeof column === 'string') {
          return { key: column, label: column };
        }

        return {
          key: column.key,
          label: column.label,
        };
      })
        .filter((column) => Boolean(column.key));
    }

    return rows[0] ? Object.keys(rows[0]).map((key) => ({ key, label: key })) : [];
  }

  private getCellValue(value: unknown): unknown {
    if (value === null || value === undefined || value === '') {
      return '—';
    }

    if (typeof value === 'boolean') {
      return value ? 'Sí' : 'No';
    }

    if (typeof value === 'string' || typeof value === 'number') {
      return String(value);
    }

    if (Array.isArray(value)) {
      return value.map((item, index) => (
        <span class="table-cell-inline" key={`${index}-${String(item)}`}>
          {this.getCellValue(item)}
        </span>
      ));
    }

    return value;
  }

  private getCellValueByColumn(columnKey: string, value: unknown): unknown {
    if (this.getDateColumnKeys().includes(columnKey)) {
      return this.getFormattedDateValue(value);
    }

    if (this.moneyColumnKeys.includes(columnKey)) {
      return this.getFormattedMoneyValue(value);
    }

    return this.getCellValue(value);
  }

  private getFormattedMoneyValue(value: unknown): string {
    const parsedMoney = this.parseMoneyValue(value);

    if (parsedMoney === null) {
      return this.getCellValue(value) as string;
    }

    return this.formatMoney(parsedMoney);
  }

  private parseMoneyValue(value: unknown): number | null {
    if (typeof value === 'number' && Number.isFinite(value)) {
      return Math.trunc(value);
    }

    if (typeof value !== 'string') {
      return null;
    }

    const raw = value.trim();
    if (!raw) {
      return null;
    }

    const sanitized = raw.replace(/[^\d,.-]/g, '');
    if (!sanitized) {
      return null;
    }

    const hasDot = sanitized.includes('.');
    const hasComma = sanitized.includes(',');
    let normalized = sanitized;

    if (hasDot && hasComma) {
      const lastDot = sanitized.lastIndexOf('.');
      const lastComma = sanitized.lastIndexOf(',');
      const decimalSeparator = lastDot > lastComma ? '.' : ',';
      const thousandSeparator = decimalSeparator === '.' ? ',' : '.';

      normalized = sanitized.split(thousandSeparator).join('');
      if (decimalSeparator === ',') {
        normalized = normalized.replace(',', '.');
      }
    } else if (hasComma) {
      normalized = /,\d{1,2}$/.test(sanitized) ? sanitized.replace(',', '.') : sanitized.split(',').join('');
    } else if (hasDot) {
      normalized = /\.\d{1,2}$/.test(sanitized) ? sanitized : sanitized.split('.').join('');
    }

    const parsed = Number(normalized);
    if (Number.isNaN(parsed)) {
      return null;
    }

    return Math.trunc(parsed);
  }

  private formatMoney(value: number): string {
    const sign = value < 0 ? '-' : '';
    const absoluteValue = Math.abs(value);
    const thousands = String(absoluteValue).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

    return `${sign}${this.moneySymbol}${thousands}`;
  }

  private getFormattedDateValue(value: unknown): string {
    const parsedDate = this.parseDateValue(value);

    if (!parsedDate) {
      return this.getCellValue(value) as string;
    }

    if (this.getDateFormat() === 'MMMdyyyy') {
      return this.formatSpecialDate(parsedDate);
    }

    return this.formatDefaultDate(parsedDate);
  }

  private parseDateValue(value: unknown): Date | null {
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
      return value;
    }

    if (typeof value === 'number') {
      const dateFromNumber = new Date(value);
      return Number.isNaN(dateFromNumber.getTime()) ? null : dateFromNumber;
    }

    if (typeof value !== 'string') {
      return null;
    }

    const trimmedValue = value.trim();
    if (!trimmedValue) {
      return null;
    }

    const directDate = new Date(trimmedValue);
    if (!Number.isNaN(directDate.getTime())) {
      return directDate;
    }

    const withoutTimezone = trimmedValue.replace(/\s[A-Z]{2,5}\s(\d{4})$/, ' $1');
    const sanitizedDate = new Date(withoutTimezone);
    if (!Number.isNaN(sanitizedDate.getTime())) {
      return sanitizedDate;
    }

    const rawDateMatch = trimmedValue.match(/^(?:[A-Za-z]{3}\s)?([A-Za-z]{3})\s(\d{1,2})\s\d{2}:\d{2}:\d{2}(?:\s[A-Z]{2,5})?\s(\d{4})$/);
    if (!rawDateMatch) {
      return null;
    }

    const monthIndex = this.monthAbbreviations.indexOf(rawDateMatch[1]);
    if (monthIndex === -1) {
      return null;
    }

    const day = Number(rawDateMatch[2]);
    const year = Number(rawDateMatch[3]);
    const manualDate = new Date(year, monthIndex, day);

    return Number.isNaN(manualDate.getTime()) ? null : manualDate;
  }

  private getDateColumnKeys(): string[] {
    return this.dateOptions?.columnKeys ?? this.dateColumnKeys;
  }

  private getDateFormat(): TableDateFormat {
    return this.dateOptions?.format ?? this.dateFormat;
  }

  private formatDefaultDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    return `${day}/${month}/${year}`;
  }

  private formatSpecialDate(date: Date): string {
    const monthLabel = this.monthLabels[date.getMonth()];
    const day = date.getDate();
    const year = date.getFullYear();

    return `${monthLabel} ${day}, ${year}`;
  }

  private handleActionCellClick(row: FormatterTableRow, event: MouseEvent) {
    const target = event.target as HTMLElement | null;

    if (!target?.closest('button')) {
      return;
    }

    this.tableActionRequested.emit({
      selectedRow: row,
      row,
      reference: row[this.referenceColumnKey],
      referenceKey: this.referenceColumnKey,
    });
  }

  render() {
    const rows = this.getResolvedRows();
    const columns = this.getResolvedColumns(rows);
    const hasRows = rows.length > 0;

    return (
      <div class={this.wrapperClass || undefined} style={this.wrapperStyle}>
        {this.tableTitle ? <div class="table-title">{this.tableTitle}</div> : null}

        <div class="table-shell">
          <table class={{ 'formatter-table': true, [this.tableClass]: Boolean(this.tableClass) }} style={this.tableStyle}>
            <thead>
              <tr>
                {columns.map((column) => (
                  <th scope="col" key={column.key}>{column.label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {hasRows ? (
                rows.map((row, index) => (
                  <tr class={{ 'is-striped': index % 2 === 1 }} key={`row-${index}`}>
                    {columns.map((column) => (
                      <td
                        key={`row-${index}-${column.key}`}
                        onClick={column.key === this.actionColumnKey ? (event) => this.handleActionCellClick(row, event) : undefined}
                      >
                        {this.getCellValueByColumn(column.key, row[column.key])}
                      </td>
                    ))}
                  </tr>
                ))
              ) : (
                <tr class="empty-row">
                  <td colSpan={columns.length || 1}>{this.emptyText}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}
