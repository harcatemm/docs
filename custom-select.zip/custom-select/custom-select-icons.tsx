// biome-ignore lint/correctness/noUnusedImports: Stencil classic JSX requires `h` in scope
import { h } from '@stencil/core';

export type CustomSelectIconName = 'chevron-up' | 'chevron-down';

export interface CustomSelectIconProps {
  name: CustomSelectIconName;
  color?: string;
  strokeColor?: string;
  size?: number | string;
  strokeWidth?: number | string;
}

export function renderCustomSelectIcon(props: CustomSelectIconProps) {
  const { name, color, strokeColor, size = 22, strokeWidth = 1.75 } = props;
  const stroke = color || 'currentColor';
  const iconSize = typeof size === 'number' ? size : Number(size) || 22;
  const iconStrokeWidth = typeof strokeWidth === 'number' ? strokeWidth : Number(strokeWidth) || 2;

  switch (name) {
    case 'chevron-up':
      return (
        <svg
          viewBox="0 0 24 24"
          width={iconSize}
          height={iconSize}
          fill="none"
          stroke={stroke}
          stroke-width={iconStrokeWidth}
          stroke-linecap="round"
          stroke-linejoin="round"
          aria-hidden="true"
          focusable="false"
          xmlns="http://www.w3.org/2000/svg"
        >
          <circle cx="12" cy="12" r="10" fill={strokeColor} stroke="none" />
          <path d="m18 15-6-6-6 6" />
        </svg>
      );
    case 'chevron-down':
      return (
        <svg
          viewBox="0 0 24 24"
          width={iconSize}
          height={iconSize}
          fill="none"
          stroke={stroke}
          stroke-width={iconStrokeWidth}
          stroke-linecap="round"
          stroke-linejoin="round"
          aria-hidden="true"
          focusable="false"
          xmlns="http://www.w3.org/2000/svg"
        >
          <circle cx="12" cy="12" r="10" fill={strokeColor} stroke="none" />
          <path d="m6 9 6 6 6-6" />
        </svg>
      );
    default:
      return null;
  }
}
