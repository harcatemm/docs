import { Component, Element, Event, EventEmitter, h, Prop, State, Watch } from '@stencil/core';
import { renderCustomSelectIcon } from './custom-select-icons';

export interface CustomSelectOption {
  key: string;
  value: string;
}

export interface CustomSelectSelection {
  key: string;
  value: string;
}

@Component({
  tag: 'custom-select',
  styleUrl: 'custom-select.css',
  shadow: true,
})
export class CustomSelect {
  @Element() el!: HTMLElement;

  @Prop() placeholder = 'Seleccione una opción';
  @Prop() options: CustomSelectOption[] = [];
  @Prop() value = '';
  @Prop({ reflect: true }) iconColor = "#ffffff";
  @Prop({ reflect: true }) iconSize: number | string = 22;
  @Prop({ reflect: true }) iconStrokeWidth: number | string = 1.75;
  @Prop({ reflect: true }) strokeColor = "currentColor";

  @State() isOpen = false;
  @State() selectedKey = '';
  @State() selectedLabel = '';

  @Event({ eventName: 'customSelectSelection', bubbles: true, composed: true })
  customSelectSelection!: EventEmitter<CustomSelectSelection>;

  componentWillLoad() {
    this.syncSelection(this.value);
  }

  componentDidLoad() {
    document.addEventListener('click', this.handleDocumentClick);
  }

  disconnectedCallback() {
    document.removeEventListener('click', this.handleDocumentClick);
  }

  @Watch('value')
  handleValueChange(newValue: string) {
    this.syncSelection(newValue);
  }

  private syncSelection(nextValue: string) {
    const option = this.options.find((item) => item.key === nextValue);
    this.selectedKey = option?.key ?? '';
    this.selectedLabel = option?.value ?? '';
  }

  private get hasSelection(): boolean {
    return Boolean(this.selectedKey || (this.selectedLabel && this.selectedLabel !== this.placeholder));
  }

  private toggleOpen = (event?: MouseEvent) => {
    event?.stopPropagation();
    this.isOpen = !this.isOpen;
  };

  private handleDocumentClick = (event: MouseEvent) => {
    const target = event.target as Node | null;
    if (target && !this.el.contains(target)) {
      this.isOpen = false;
    }
  };

  private handleOptionSelect = (option: CustomSelectOption, event?: MouseEvent) => {
    event?.stopPropagation();
    this.selectedKey = option.key;
    this.selectedLabel = option.value;
    this.isOpen = false;
    this.customSelectSelection.emit({ key: option.key, value: option.value });
  }

  private renderChevronIcon() {
    return renderCustomSelectIcon({
      name: this.isOpen ? 'chevron-up' : 'chevron-down',
      color: this.iconColor,
      strokeColor: this.strokeColor,
      size: this.iconSize,
      strokeWidth: this.iconStrokeWidth,
    });
  }

  render() {
    const selectedLabel = this.selectedLabel || this.placeholder;

    return (
      <div class="select-wrapper">
        <button
          type="button"
          class={{
            'select-trigger': true,
            'is-open': this.isOpen,
            'has-selection': this.hasSelection,
          }}
          onClick={this.toggleOpen}
        >
          <span class={{ 'select-value': true, 'is-placeholder': !this.selectedLabel }}>{selectedLabel}</span>
          {this.renderChevronIcon()}
        </button>

        {this.isOpen ? (
          <ul class="select-options" role="listbox">
            {this.options.map((option) => (
              <li
                key={option.key}
                class={{ 'select-option': true, 'is-selected': option.key === this.selectedKey }}
                onClick={(event: MouseEvent) => this.handleOptionSelect(option, event)}
              >
                {option.value}
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    );
  }
}
